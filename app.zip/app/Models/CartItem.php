<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CartItem extends Model
{
    protected $fillable = [
        'cart_id',
        'product_variant_id',
        'combo_id',
        'quantity',
        'unit_price',
    ];
    protected function casts(): array
    {
        return ['quantity' => 'integer', 'unit_price' => 'integer',];
    }
    public function cart(): BelongsTo
    {
        return $this->belongsTo(Cart::class);
    }
    public function productVariant(): BelongsTo
    {
        return $this->belongsTo(ProductVariant::class);
    }
    public function combo(): BelongsTo
    {
        return $this->belongsTo(Combo::class);
    }
}
